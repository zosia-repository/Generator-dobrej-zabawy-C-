#ifndef ODCZYTYWANIE_H
#define ODCZYTYWANIE_H


#include <string>

using namespace std;

string odczytajPlik(const char* sciezkaPliku);

#endif
