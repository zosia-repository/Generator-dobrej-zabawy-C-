#ifndef TYPJEDZENIA_H
#define TYPJEDZENIA_H

enum TypJedzenia {
    MEKSYKANSKIE,
    INDYJSKIE,
    SUSHI,
    AMERYKANSKIE,
    POLSKIE,
    WEGETARIANSKIE,
    KEBABY,
    DESERY,
    FAST_FOOD,
    ILOSC_TYPOW
};

#endif
